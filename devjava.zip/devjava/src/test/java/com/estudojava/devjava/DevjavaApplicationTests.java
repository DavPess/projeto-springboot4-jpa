package com.estudojava.devjava;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DevjavaApplicationTests {

	@Test
	void contextLoads() {
	}

}
